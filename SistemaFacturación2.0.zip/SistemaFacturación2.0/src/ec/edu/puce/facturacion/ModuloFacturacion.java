package ec.edu.puce.facturacion;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ModuloFacturacion extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JTextField txtCedulaCliente;
    private JTextField txtCodigoProducto;
    private JTextField txtCantidad;
    private JTable tablaProductosFactura;
    private DefaultTableModel modeloTabla;

    public ModuloFacturacion() {
        setTitle("Modulo de Facturación");
        setBounds(100, 100, 800, 600);
        getContentPane().setLayout(null);

        JLabel lblCedulaCliente = new JLabel("Cédula Cliente:");
        lblCedulaCliente.setBounds(20, 20, 120, 25);
        getContentPane().add(lblCedulaCliente);

        txtCedulaCliente = new JTextField();
        txtCedulaCliente.setBounds(140, 20, 150, 25);
        getContentPane().add(txtCedulaCliente);
        txtCedulaCliente.setColumns(10);
        
        JButton btnBuscarCliente = new JButton("Seleccionar Cliente");
        btnBuscarCliente.setBounds(300, 20, 150, 25);
        getContentPane().add(btnBuscarCliente);

        JLabel lblCodigoProducto = new JLabel("Código Producto:");
        lblCodigoProducto.setBounds(20, 60, 120, 25);
        getContentPane().add(lblCodigoProducto);

        txtCodigoProducto = new JTextField();
        txtCodigoProducto.setBounds(140, 60, 150, 25);
        getContentPane().add(txtCodigoProducto);
        txtCodigoProducto.setColumns(10);

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(300, 60, 120, 25);
        getContentPane().add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setBounds(370, 60, 80, 25);
        getContentPane().add(txtCantidad);

        JButton btnAgregarProducto = new JButton("Agregar Producto");
        btnAgregarProducto.setBounds(460, 60, 150, 25);
        getContentPane().add(btnAgregarProducto);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 100, 750, 300);
        getContentPane().add(scrollPane);

        modeloTabla = new DefaultTableModel(
            new Object[][] {},
            new String[] {"Código", "Nombre", "Precio", "Cantidad", "Subtotal"}
        );
        tablaProductosFactura = new JTable(modeloTabla);
        scrollPane.setViewportView(tablaProductosFactura);

        JButton btnGuardarFactura = new JButton("Guardar Factura");
        btnGuardarFactura.setBounds(20, 420, 150, 25);
        getContentPane().add(btnGuardarFactura);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(200, 420, 150, 25);
        getContentPane().add(btnCancelar);

        // Action Listeners

        txtCedulaCliente.addActionListener(e -> cargarDatosCliente());

        btnBuscarCliente.addActionListener(e -> seleccionarCliente());

        txtCodigoProducto.addActionListener(e -> cargarDatosProducto());

        btnAgregarProducto.addActionListener(e -> agregarProductoAFactura());

        btnGuardarFactura.addActionListener(e -> guardarFactura());

        btnCancelar.addActionListener(e -> dispose());
    }

    private void cargarDatosCliente() {
        String cedula = txtCedulaCliente.getText();
        Cliente cliente = buscarClientePorCedula(cedula);
        if (cliente != null) {
            JOptionPane.showMessageDialog(this, "Cliente: " + cliente.getNombres() + "  " + cliente.getApellidos() + "/ Cedula: " + cliente.getCedula() + "/ Direccion:" + cliente.getDireccion() + "/ Correo: " + cliente.getEmail() + "/  Numero: " + cliente.getTelefono());
        } else {
            JOptionPane.showMessageDialog(this, "Cliente no encontrado");
        }
    }	

    private Cliente buscarClientePorCedula(String cedula) {
        for (Cliente cliente : TablaDeClientes.getListaClientes()) {
            if (cliente.getCedula().equals(cedula)) {
                return cliente;
            }
        }
        return null;
    }

    private void seleccionarCliente() {
        TablaDeClientes tablaClientes = new TablaDeClientes(true); // Modo selección sin botones
        JDialog dialog = new JDialog();
        dialog.setTitle("Seleccionar Cliente");
        dialog.setSize(600, 400);
        dialog.setModal(true);
        dialog.getContentPane().add(tablaClientes.getContentPane());
        dialog.setVisible(true);

        JTable tabla = tablaClientes.getTablaClientes();
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) { // Doble clic en la fila
                    int row = tabla.getSelectedRow();
                    if (row != -1) {
                        String cedula = (String) tabla.getValueAt(row, 0); // Obtener cédula de la primera columna
                        txtCedulaCliente.setText(cedula); // Asignar al campo de texto
                        dialog.dispose(); // Cerrar el diálogo
                    }
                }
            }
        });
    }

    private void cargarDatosProducto() {
        String codigo = txtCodigoProducto.getText();
        Producto producto = buscarProductoPorCodigo(codigo);
        if (producto != null) {
            JOptionPane.showMessageDialog(this, "Producto: " + producto.getNombre());
            txtCantidad.requestFocus();
        } else {
            JOptionPane.showMessageDialog(this, "Producto no encontrado");
        }
    }

    private Producto buscarProductoPorCodigo(String codigo) {
        // Simulación de búsqueda de producto
        for (Producto producto : TablaDeProductos.getListaProductos()) {
            if (producto.getCodigo().equals(codigo)) {
                return producto;
            }
        }
        return null;
    }

    private void agregarProductoAFactura() {
        String codigo = txtCodigoProducto.getText();
        String cantidadStr = txtCantidad.getText();

        Producto producto = buscarProductoPorCodigo(codigo);
        if (producto != null) {
            try {
                int cantidad = Integer.parseInt(cantidadStr);
                int stockActual = Integer.parseInt(producto.getStock());
                double precio = Double.parseDouble(producto.getPrecio());

                // Verificar stock disponible
                if (cantidad > stockActual) {
                    JOptionPane.showMessageDialog(
                        this,
                        "Stock insuficiente. Solo hay " + stockActual + " unidades disponibles.",
                        "Error de Stock",
                        JOptionPane.ERROR_MESSAGE
                    );
                    return;
                }

                // Calcular subtotal y actualizar stock
                double subtotal = precio * cantidad;
                int nuevoStock = stockActual - cantidad;

                // Actualizar el stock del producto
                producto.setStock(String.valueOf(nuevoStock));

                // Agregar producto a la tabla de factura
                modeloTabla.addRow(new Object[]{
                    producto.getCodigo(),
                    producto.getNombre(),
                    producto.getPrecio(),
                    cantidad,
                    subtotal
                });

                // Limpiar campos de entrada
                txtCodigoProducto.setText("");
                txtCantidad.setText("");
                txtCodigoProducto.requestFocus();

                JOptionPane.showMessageDialog(
                    this,
                    "Producto agregado con éxito. Stock restante: " + nuevoStock,
                    "Producto Agregado",
                    JOptionPane.INFORMATION_MESSAGE
                );
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Cantidad o datos del producto inválidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Producto no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarFactura() {
        JOptionPane.showMessageDialog(this, "Factura guardada con éxito");
        modeloTabla.setRowCount(0); // Limpiar la tabla tras guardar
    }
    
    public void setCedulaClienteSeleccionada(String cedula) {
        txtCedulaCliente.setText(cedula); // Establece la cédula en el campo de texto
    }
}


